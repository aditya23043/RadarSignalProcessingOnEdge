// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.1 (64-bit)
// Tool Version Limit: 2022.04
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/COR)
//        bit 0 - ap_done (Read/COR)
//        bit 1 - ap_ready (Read/COR)
//        others - reserved
// 0x10 : Data signal of sync_reset
//        bit 0  - sync_reset[0] (Read/Write)
//        others - reserved
// 0x14 : reserved
// 0x18 : Data signal of trigger_done
//        bit 0  - trigger_done[0] (Read)
//        others - reserved
// 0x1c : // (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XTRIGGER_IP_CONTROL_ADDR_AP_CTRL           0x00
#define XTRIGGER_IP_CONTROL_ADDR_GIE               0x04
#define XTRIGGER_IP_CONTROL_ADDR_IER               0x08
#define XTRIGGER_IP_CONTROL_ADDR_ISR               0x0c
#define XTRIGGER_IP_CONTROL_ADDR_SYNC_RESET_DATA   0x10
#define XTRIGGER_IP_CONTROL_BITS_SYNC_RESET_DATA   1
#define XTRIGGER_IP_CONTROL_ADDR_TRIGGER_DONE_DATA 0x18
#define XTRIGGER_IP_CONTROL_BITS_TRIGGER_DONE_DATA 1

